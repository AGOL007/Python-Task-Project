# -*- coding: utf-8 -*-
""" Unit test file """

__author__ = 'ShashankSi'

import unittest
from TestBase import set_browser
import SeleniumValidation
import SeleniumCommonActions
import csv
class MyTestCase(unittest.TestCase):
    """ Test Class """

    def getNumberOfCount(filename):
        with open(filename,"r") as f:
            reader=csv.reader(f)
            data=list(reader)
            row_count=len(data)
            ##  next(reader, None)  # skip the headers
            ##  row_count = sum(1 for row in reader)
            return row_count

    def test_esri_app(self):
        """Test Method"""

        with open(r"C:\Users\ajaygi\Desktop\Modal-Link.csv",'r') as SiteInfoFile:
            testDriver = self.driver
            examplereader = csv.reader(SiteInfoFile)
            data = list(examplereader)

            for row in data:
                i = 0
                testDriver.get(row[i])
                #   Check class 'fancybox-skin' is present
                if SeleniumValidation.check_fancybox_class(self.driver):
                    print("1: Class 'fancybox-skin' is not visible")

                    #   Perform Rich Data Actions
                    SeleniumCommonActions.action_on_richdata(self.driver)
                else:
                    print ("Class 'fancybox-skin' is visible")
                    assert False


                #   Check class 'fancybox-skin' is present
                if SeleniumValidation.check_fancybox_class(self.driver):
                    print ("2: Class 'fancybox-skin' is not visible")
                    assert True
                else:
                    print ("Class 'fancybox-skin' is visible")
                    assert False

                i += 1

    def setUp(self):
        """ Intiate and maximize the browser """
        self.driver = set_browser()
        self.driver.maximize_window()


    def tearDown(self):
        """ Quit browser"""
        self.driver.close()


if __name__ == '__main__':
    unittest.main()
